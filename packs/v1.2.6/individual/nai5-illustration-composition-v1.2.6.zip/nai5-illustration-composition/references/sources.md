<a id="comic-sources.preamble"></a>

# 创作方法来源

本文件用于用户明确要求的方法出处核对或创作研究，不是普通构思的必读步骤。日常任务直接使用相应方法；不沿来源入口自主查找旧图、逐图分析或历史作品来补题。用户已提供或指定参考时，按本次范围分析。

> Copyright (C) 2026 Miint-Sunny
> SPDX-License-Identifier: GPL-3.0-only
> 项目与公开来源：[Miint-Sunny/nai5-prompting](https://github.com/Miint-Sunny/nai5-prompting)。
> 许可全文：[GNU GPL version 3](https://www.gnu.org/licenses/gpl-3.0.html)；贡献范围与第三方材料说明见 [NOTICE](https://github.com/Miint-Sunny/nai5-prompting/blob/main/NOTICE)。

以下列出方法来源与内容定位。官方能力和字段应用的来源另见写法包。

<a id="comic-sources.s01"></a>

### 视频：原片观点与本领域方法转化

| 来源 | 主要吸收内容（时间为近似定位） |
|---|---|
| [Parion圆周率：《漫画家不会告诉你的20大技巧·分镜篇》](https://www.bilibili.com/video/BV1VT411K7RS/) | 00:12格面积/景别；02:48环境；03:40动作前后；05:20正反打与轴线；07:14连续蒙太奇的删格案例；09:40起不同连接方式；14:14起重复构图与跨时空连接 |
| [Parion圆周率：《漫画家不会告诉你的20大技巧·平面篇》](https://www.bilibili.com/video/BV19G411b7tB/) | 00:08间距分组；00:52字距与字体；01:54起气泡与声效；04:26跨页；04:56起破格、插格和互动格；06:40起留白、无框、背景格、装饰与叠像 |

视频作者将内容定位为个人经验；本领域方法不把20条当作标准答案。尤其做了以下区分：

- 格子面积与镜头景别分开控制；格数与阅读速度不建立必然关系。
- 预示/关键/反应是可压缩、可省略的组织方式，不要求所有动作占三格。
- 连续叙事的删格会改变动机；有意义的静止、重复、空镜仍可保留。
- 版式与象征层不等于场景中的真实物体；心理黑底不自动成为夜晚，叠像人物不成为现场巨人。
- 作品案例用于理解演出功能，不把视频画面的作者当作用户授权的 NAI 画师串。

<a id="comic-sources.s02"></a>

### 网上教程：按制作问题索引

| ID / 来源 | 贡献与使用边界 |
|---|---|
| W1 [Steve Ellis：Pro Artist’s Guide to Comic & Manga Layouts, Paneling, Flow](https://www.clipstudio.net/how-to-draw/archives/160963) · CLIP STUDIO Art Rocket | 从缩略布局建立页面路线，再安排大小格、插格和重点；脸、气泡与画格要共同引导下一步。具体布局示例是选择，不是唯一模板。 |
| W2 [MediBang：Manga Tutorial for Beginners 02 — Let’s Make Outline (Part 1)](https://medibangpaint.com/en/use/2021/06/mangatutorialforbeginners02/) · 2021-06-12 | 可以从主题、氛围、人物或视觉点子启动创作；有趣的格型需服务具体故事，不强制所有人使用同一构思入口。 |
| W3 [MediBang：Manga Tutorial for Beginners 03 — Let’s Make Outline (Part 2)](https://medibangpaint.com/en/use/2021/07/mangatutorialforbeginners03/) · 2021-07-10 | 角色设计和表情帮助形成可见性格；起承转合、序破急是组织剧情的工具，人物行为仍要有动机。 |
| W4 [MediBang：Manga Tutorial for Beginners 05 — Let’s Make Name (outline)](https://medibangpaint.com/en/use/2021/08/mangatutorialforbeginners05/) · 2021-08-07 | Name阶段用粗略布局、对白和流程低成本改稿；同一剧情的双页、单页与随笔式布局会改变揭示时机和节奏，需按篇幅与读感选择。 |
| W5 [MediBang：Manga Tutorial for Beginners 06 — Let’s Think About Frame Layout and Screen](https://medibangpaint.com/en/use/2021/09/mangatutorialforbeginners06/) · 2021-09-11 | 人物、对白、运动线参与阅读引导；必要的环境信息让读者定位。文中格数建议不转成所有页漫的固定配额。 |
| W6 [MediBang：Manga Tutorial for Beginners 08 — Let’s Draw Frames and Speech Bubbles](https://medibangpaint.com/en/use/2021/11/mangatutorialforbeginners08/) · 2021-11-20 | 用格间距区分同组与跨组阅读，并在制作中处理边框与气泡。保留分组思想，不把软件操作步骤写进 NAI 提示词。 |
| W7 [Taiyo Nakashima / SMA：Japanese Manga 101 #003 — Art of Paneling, Basics 1](https://www.manga-audition.com/japanesemanga101_003/) · 2015-01-23 | 重要情绪变化可放大，前导与余味帮助读者感受变化；与视频的动作前后结构相互补充，而非每次固定三格。 |
| W8 [69Michi：Webtoon 101 — By an Original WEBTOON creator](https://tips.clip-studio.com/en-us/articles/4143) · CLIP STUDIO TIPS | 以滚动视窗组织揭示、纵向背景、尺度和声效转场。这是创作者经验，不能误称平台强制规范。 |
| W9 [Manny Guevarra：How to Panel Comics for WEBTOON and Print](https://tips.clip-studio.com/en-us/articles/9420) · CLIP STUDIO TIPS | 页漫的整页可见与条漫的滚动可见不同；早留气泡、保留独立图层有利于两种媒介重编。涉及平台尺寸的旧数字不当作现行限制。 |
| W10 [Nate Piekos / Blambot：Comic Book Grammar & Tradition](https://blambot.com/pages/comic-book-grammar-tradition) | 气泡尾巴、说话归属与声音表现有助于图文整合。英文漫画的字体、标点和传统禁忌不直接套给中文或所有画风。 |
| G1 [SILENT MANGA AUDITION：Rules & Guidelines](https://www.manga-audition.com/rules-guidelines/) · 创作指南部分 | 双页作为阅读画布、页尾引导下一页、简单清晰的情绪故事。这里只吸收叙事建议；赛事的页数、方向和无对白要求不成为通用漫画规则。 |

<a id="comic-sources.s04"></a>

### 综合方法如何对应来源

| 技能决策 | 主要证据 |
|---|---|
| 意图→可见演出→阅读节拍 | 分镜篇；W2–W4；W7 |
| 事件顺序与读者得到信息的顺序分开 | 分镜篇连续/交叉/心理连接；W4的页数比较；G1 |
| 故事时间、阅读时间和情绪节拍分开 | 对两段视频的综合分析，结合W4/W7/W8；是本领域方法的整理框架 |
| 入口、重点、出口与气泡先行 | 平面篇；W1/W5/W6/W10 |
| 真正翻页后/屏下再揭晓 | W4；W8/W9；G1 |
| 全页版式、逐格可见内容、后期文字的作用域 | 创作阶段区分阅读布局与文字位置；接口字段和应用反馈另存写法来源 |
| 整页与逐格两条制作路线 | 保留完整阅读设计，再按制作环境选择；不是官方优劣排名 |

<a id="costume-design.s12"></a>

### 方法来源

- [POSEMANIACS：オリジナルキャラに合う衣装の決め方](https://www.posemaniacs.com/courses/4884b467-45c2-4db0-b995-2fa9e3a14b25)
- [CLIP STUDIO TIPS：Drawing Clothing for Manga and Anime](https://tips.clip-studio.com/en-us/articles/4496)
- [CLIP STUDIO TIPS：Character Design—Costume](https://tips.clip-studio.com/en-us/articles/1957)
- [Proko：Drapery Fundamentals](https://www.proko.com/course/drapery-fundamentals/comments)
- [Proko：Batman Drapery Studies](https://www.proko.com/course-lesson/batman-drapery-studies)
- [FASHIONPEDIA 官方介绍](https://fashionary.org/products/fashionpedia)
- [京都服饰文化研究财团数字档案](https://www.kci.or.jp/en/archives/digital_archives/)
- [V&A Fashion Collection](https://www.vam.ac.uk/collections/fashion)
- [The Met Costume Institute](https://www.metmuseum.org/about-the-met/collection-areas/the-costume-institute)


<a id="ideation-sources.background"></a>

### 背景资料核对

参考 [Elowwwen / Fanfic-background-assistant](https://github.com/Elowwwen/Fanfic-background-assistant) 的 `0b5da382b5f5d0150b406bc66bfbc0c4aaa11e3f` 版本。上游采用 MIT License，Copyright (c) 2026 Elowwwen；许可原文随本项目 `NOTICE` 保留。

本项目将以下方法改写为场景、角色与服装设计包内的按需参考 `references/background.md`：

- [领域导览](https://github.com/Elowwwen/Fanfic-background-assistant/blob/0b5da382b5f5d0150b406bc66bfbc0c4aaa11e3f/fanfic-background-assistant/references/domain-orientation.md)：从职业流程、可获得的器物与日常运行中找到实际条件，落实到本次画面的工具、路径、取放与穿用关系。
- [研究与风险核对](https://github.com/Elowwwen/Fanfic-background-assistant/blob/0b5da382b5f5d0150b406bc66bfbc0c4aaa11e3f/fanfic-background-assistant/references/research-and-risk.md)：核对来源适用的年代、地区和身份，区分事实与推断，保留用户意图及已定架空规则。

仅采用按需核对资料的方法，不要求编写背景手册或持续记录。

<a id="ideation-sources.action"></a>

### 动作设计方法

动作阶段选择、身体支撑与配合、可见后果及取景判断参考了署名 antimomi 的《动作扩写》所提示的问题，按本项目的任务分工重新表述，放在 `references/composition.md` 的动作章节。原文中的完整场景示例、固定戏剧机位、默认环境破坏、强制英文主副标题与输出格式没有并入；原文件未随包分发。

<a id="ideation-sources.archive"></a>

### 用户材料的叙事经验

归档《分镜脚本提示词（例）》支持“剧情节点—页级节奏—逐格镜头、文字和衔接”的制作顺序，以及避免没有作用的连续大头、让静默格有意义、页尾与下页协作等方法。它原来用于剧本改编，原件中的不新增剧情、续写位置和读向并非所有原创任务的要求。

归档反馈里，毯子边沿漂移、包的开合机构改变、连续持物丢失、灰阶明暗变化，分别促成当前的持续状态、道具结构与明暗连续性检查。
