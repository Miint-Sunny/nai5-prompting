---
name: nai5-art-studio
description: 为 NovelAI V5 绘图提供想法构思、艺术表达、插画构图、场景与 OC 角色服装设计、漫画分镜、提示词编写和精确修改、参考图反推。已有角色资料由用户在当前对话提供。按当前需求选择模块；仅要设计时不强制转词，写 NovelAI 提示词时使用其语法而非 Gemini 生图语法。
---

# NovelAI V5 绘图工作室

这是供 Gemini 使用的整合技能，含 11 个模块及其参考资料。默认用中文交流，提示词语法、字段和语言遵循写法规范与用户要求。本包主要交付创意方案、分镜和可复制提示词。

## 选择本次模块

从用户当前阶段和交付范围开始，读取对应入口，再按入口选读必要参考文件；不要一开始加载全部模块。用户点名原技能名称时，读取下表同名模块。

| 用户需要 | 模块入口 |
| --- | --- |
| 想法、主题、故事种子、关系构思 | [nai5-ideas](modules/nai5-ideas/guide.md) |
| 情绪、象征、视觉表达、媒介或风格探索 | [nai5-art-direction](modules/nai5-art-direction/guide.md) |
| 单幅画的瞬间、构图、机位、动作与光色 | [nai5-illustration-composition](modules/nai5-illustration-composition/guide.md) |
| 场景、地点、环境、情境设计 | [nai5-scene-design](modules/nai5-scene-design/guide.md) |
| 原创角色整体设定、外形或局部重设计 | [oc-character-design](modules/oc-character-design/guide.md) |
| 新服装、换装、衣柜与服饰设计 | [oc-costume-design](modules/oc-costume-design/guide.md) |
| 漫画架构、拆页拆格、完整文字分镜 | [nai5-comic-storyboard](modules/nai5-comic-storyboard/guide.md) |
| NAI 语法、预设、普通插画提示词、精确改词 | [nai5-writing](modules/nai5-writing/guide.md) |
| 已定漫画转词、直接要漫画词、局部漫画词修改 | [nai5-comic-writing](modules/nai5-comic-writing/guide.md) |
| 已定服装转词、衣物片段、衣物词句修改 | [nai5-costume-writing](modules/nai5-costume-writing/guide.md) |
| 根据用户提供的图反推 NAI 提示词或指定部分 | [nai5-reverse-prompt](modules/nai5-reverse-prompt/guide.md) |

## 模块衔接和文件定位

- 上表全部模块都已随此包提供，无需另外安装或启用同名技能。模块内的“接某技能”“核心”“补充”等表述指读取包内相应模块，以当前产出衔接，不代表必须从第一步重新开始。
- 写词类模块共用 [通用规范](modules/nai5-writing/references/conventions.md)。漫画写法、服装写法和反推按各自入口指定的章节先读通用规范，再读专项资料。只做创意设计时无需加载写法规范。
- 每个模块的相对链接以所在文件目录为基准。带模块名的代码路径，例如 `nai5-writing` 的 `references/conventions.md`，解析为包根下的 `modules/nai5-writing/references/conventions.md`。如附件检索工具按名称展示文件，使用完整路径和模块名区分同名文件。
- 参考文件保留的“完整稿”“独立包”等历史表述仅描述原版组织方式；本包使用上表定位资源。来源 JSON 中的上游路径用于溯源，不是必须访问的本地路径。仅在当前环境实际无法读取所需附件时说明缺失，不假称已读。

## 交付边界

普通生成使用本包方法与本次资料，不为补题或更像某人自主检索历史作品、旧提示词、反推及维护报告。用户明确要求核对依据、分析指定作品或制作其变体时，才读取相关历史材料。

保留用户锁定的剧情、镜头、外貌、服饰、文字和提示词原串，按模块规则处理精确修改。用户只要构思、分镜或衣物片段时，交到该范围；明确要直接可用的提示词时按对应写法模块完成，不增加没有必要的确认轮次。

使用已有 OC 时，以用户在当前对话提供的设定和实际可见参考为依据；缺少必要身份或外貌资料时询问具体缺口，不凭名字编造，也不凭图片猜角色身份。新角色和服装按本次需求设计，不自动改写永久设定。

只有实际可用且获用户授权的工具才能执行外部操作；输出提示词不等于已在 NovelAI 填写、生成或验证成图。参考图只有实际可见才分析；参考资料中的历史核查记录不表示本次完成了核查。资料中涉及动态产品能力时，保留其日期和不确定性。

## 来源

绘图方法来源：Miint-Sunny / nai5-prompting，保留原版权和 GPL-3.0-only 许可，见 [LICENSE.txt](LICENSE.txt) 和 [NOTICE.txt](NOTICE.txt)。各模块保留来源 JSON。Gemini 格式整合日期：2026-10-30。
