<a id="writing-sources"></a>

# 写法来源与证据边界

本文件记录方法出处与适用边界。技术语法、术语或当前能力需要核实时，读取对应技术节；用户明确要求核对历史依据时，再读相应归档说明。普通写词不沿历史来源自主检索旧图、完整原串或反推来补画面内容。

> Copyright (C) 2026 Miint-Sunny
> SPDX-License-Identifier: GPL-3.0-only
> 项目与公开来源：[Miint-Sunny/nai5-prompting](https://github.com/Miint-Sunny/nai5-prompting)。
> 许可全文：[GNU GPL version 3](https://www.gnu.org/licenses/gpl-3.0.html)；贡献范围与第三方材料说明见 [NOTICE](https://github.com/Miint-Sunny/nai5-prompting/blob/main/NOTICE)。

保留既有方法的出处、用户归档反馈与小样本记录；不把历史判断写成本轮新做的实验，也不据此宣称新任务的稳定成功率。方法源于本项目现行整合稿，基础写法延续 v1.1；本次调整的是职责与混杂表达。

<a id="general-writing.s12"></a>

### 附：判据与证据边界

写法判据来自既有出图对照与提示词材料。完整计数、分母、样例与重判记录保存在维护证据中，
正文保留使用时需要知道的结论：

| 判据 | 已观察到什么 | 使用边界 |
|---|---|---|
| 姿势、机位高低用词组 | 对照中比长句更清楚；姿势在不同画师串下复现 | 样本少，不能当成功率或所有题材的保证 |
| 服装形制用词组，状态与位置用句子 | 修正词义后形制稳定；状态句能做出不对称 | 具体滑落位置仍不稳定 |
| 场景清单配整体性句 | 有助于保持物件可辨认 | 不能保证复杂场景全部准确 |
| 光影方向句配方向词 | 方向句出现过反向结果 | 不把「能写」当成「一定执行」 |
| 多人施受与空间层次分开处理 | 前缀用于动作方向，Position 用于层次 | 编号、人数和复杂交互仍可能出错 |

对照只覆盖有限场景，未充分验证所有混合写法。测试判读和失败个例的原始记录见
《20260825-笔法对照实测》（维护记录，未随包分发） 与 《20260827-服装状态对照》（维护记录，未随包分发）。
正常出图种子随机；固定种子仅用于对照取证。

提示词材料中的频次可作为默认写法的参考，不代表只能这样写，也不证明发图者内在动机。
收藏接入批次不是生成时间；版本、识别轴和标签阈值的差异不能直接解释成偏好变化。
`res_mult:Nx` 已有实际使用样例，但缺少效果对照；`face focus` 的词典记录不明确，使用时注明不确定性。
遇到未覆盖的需求，按画面意图、语义与运行环境能力处理，不硬套已有案例。


> **基础内容说明**：标准方法可独立使用，历史案例中的来源标识已作匿名化处理。
> 用户实际提供补充说明时，按其指定范围生效；未覆盖的部分按标准方法执行。
> 语法与能力边界以运行环境为准，不推定还挂载了其他文件或题材池。

<a id="comic-sources.s03"></a>

### NovelAI：只把官方描述当作能力依据

| 来源 | 已确认与保留疑问 |
|---|---|
| N1 [NovelAI Diffusion V5](https://novelai.net/v5) | 支持自然语言描述整页分格；支持多角色；前端可根据引号自动建立文字块。它没有保证任意几何布局或每格身份都能一次准确。图像参考与重绘须按选定模型的当前界面确认，不沿用旧发布页的“后续上线”承诺。 |
| N2 [Text Rendering](https://docs.novelai.net/en/image/textrendering/) | V5支持中文等文字及位置/载体描述；Full上限写750字符，Curated写374字符，包含空格和换行。文字未出现时可检查质量词中的文字排除。 |
| N3 [Image Generation Models](https://docs.novelai.net/en/image/models/) | 概览对相同渲染文字容量使用 tokens，与文字专页单位不一致；提示词本身的 token 容量又是另一项。本项目按文字专页字符口径引用，保留差异。 |
| N4 [Quality Tags](https://docs.novelai.net/en/image/qualitytags/) | V5 Standard 与 Light 附加内容不同，均须按实际生效词去重和处理文字冲突，不能假定预设恒开。 |
| N5 [Precise Reference](https://docs.novelai.net/en/image/precisereference/)、[Vibe Transfer](https://docs.novelai.net/en/image/vibetransfer/)、[Inpaint](https://docs.novelai.net/en/image/inpaint/) | 本项目 2026-09-14 核对时，Precise 文档仍标 V4.5 专有；另外两页没有完整的 V5 Full / Curated 支持矩阵。按所选模型界面确认，不推测缺项支持。 |
| N6 [Multiple Characters](https://docs.novelai.net/en/image/multiplecharacters/) | 角色位置在角色提示词区从 AI's Choice 改成 Custom，点 Character Positions 按钮在画布上摆放，模型会贴着摆放的位置画；V4 与 V4.5 限 5×5 网格，V5 没有这项限制，是自由画布。本页写 V5 最多 22 个角色、V4 最多 6 个；N1 的 V5 页同样写最多 22 个、可把角色放在画布任意位置。每个角色另有自己的 Undesired Content 栏。本项目 2026-09-24 核对。 |
| N7 [Tags](https://docs.novelai.net/en/image/tags/) 的 Alpha Transparency 一节 | `transparent background` 让背景透明；`has alpha` 较抽象，表示要以某种方式用到 alpha 通道；`alpha transparency` 让画面里的物体以 alpha 通道方式透空（例子是魔法特效、火焰、伞），只在 V5 可用。本项目 2026-09-24 核对。 |

基础语法、字段与原串依本包共同规范，OC 库仅在用户需要且实际启用时读取；方法导航见 [写法入口](conventions.md#writing-conventions)。漫画默认字段分工按用户后续要求采用“主 Prompt 写本页去重人数标签与简短版式、Character 框承载各格内容”，详见 “漫画提示词编译”（`nai5-comic-writing`：`references/comics.md#comic-adapter.preamble`）。这是个人工作流及实图反馈支持的应用方式，不能包装成官方逐格 API；故事身份、画格与提示框数量分别计算。

<a id="comic-sources.s05"></a>

### 用户分镜参考与实图反馈

归档材料中的《分镜脚本提示词（例）》用于支持“剧情节点→页级节奏→逐格镜头/文字/衔接”的制作顺序，以及精简对白、避免连续大头、无台词格有作用、重要节点考虑页尾等建议。该文档原本服务于已有剧本改编，右→左阅读、不新增剧情、从已有页面续写等条件，不自动成为用户原创任务的要求；格数参考的适用范围见页级规划，不当作硬配额。

归档材料记录了右→左、上→下、人物去重计数、简短版式与可见状态连续等用户约定。其中读向已于 2026-09-24 按用户决定改为从左往右（四格默认 2×2），其余约定本项目延续。它们不是官方接口规则；实际生成单元与用户当前要求优先。

| 归档材料记录的反馈 | 保留的写法 |
|---|---|
| 角色提示框分别写分镜可行，但每格双人、同机位导致平淡且冗长 | 采用角色框承载分镜；先改变出场与镜头调度，主串内容部分只放人数标签与简短版式，质量尾另按实际预设处理 |
| 两只手的互动被分别画成两个窄格 | 无可识别主体的局部互动合为一个框；可识别多人同格仍每人一个框 |
| 大幅场景中的“只入画一只手”难以成立 | 镜头尺寸、机位、画外身体与动作可达性先校验，必要时改景别/站位 |
| 毯子前格到颈部，后格降到腹部 | 覆盖边沿用身体锚点保持一致，变化安排可理解的动作 |
| 分页独立生成的布景与衣服变化明显 | 简化小格背景、减少跨页同角度复杂全景对照；服装结构保持一致 |
| 删去彩色词后，同一人的头发由深变浅 | 黑白保留并重复明暗锚点，去色相不等于去掉深浅 |
| 包的样式、开口机构与附件容易改变 | 固定结构与当前状态分开；后续要操作的结构先建立；实际归因须核对原提示词 |
| 不需要逐格写“无文字”；旁白与对白需明确载体 | 静默格省略文字指令，旁白用 Narrator box，对白用 speech bubble |

契诃夫之枪在此作为创作取舍原则：先建立会使用的功能，删掉没有作用的强调细节；身份、空间、气氛与停顿本身也可以构成作用，不要求故事开头立即兑现全部伏笔。

这些是归档材料描述的局部经验。没有掌握所有生成设置、seed、完整原始输入及批量结果，不能提供成功率或保证某个短语必然控制几何。每项修订需区分“用户已看到的结果”“提示词内部修正”与“尚未得到新图的写法”；归档时的换装与厨房道具脚本没有对应出图记录；本次漫画候选也只完成文字与离线核验，均不计为新出图验证。

<a id="costume-writing.s10"></a>

### 查询依据

以下链接沿用归档的术语查询依据；未经本次实际查询的词不标作已验证。

- [FASHIONPEDIA 官方介绍](https://fashionary.org/products/fashionpedia)
- [Danbooru API：Tags（Safebooru 镜像）](https://safebooru.donmai.us/wiki_pages/api%3Atags)
- [Danbooru API Help（Safebooru 镜像）](https://safebooru.donmai.us/wiki_pages/help%3Aapi)
- [Danbooru Tag 模型源码](https://github.com/danbooru/danbooru/blob/master/app/models/tag.rb)
